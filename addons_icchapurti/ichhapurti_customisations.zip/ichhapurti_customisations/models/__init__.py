# -*- coding: utf-8 -*-

from . import stock_warehouse, res_partner, sale_order, \
    purchase_order, res_users, product_template, res_company
